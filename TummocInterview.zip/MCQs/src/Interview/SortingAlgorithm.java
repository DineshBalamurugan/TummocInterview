package Interview;

import java.util.Arrays;

public class SortingAlgorithm {

    static void mergeSort(int[] array, int s, int e){

        if(e - s == 1){
            return;
        }

        int mid = (s + e) / 2;

        mergeSort(array, s, mid);
        mergeSort(array, mid, e);

        merge(array, s, mid, e);

    }

    static void merge(int[] array, int s, int mid, int e){

        int[] mix = new int[e - s];

        int i = s;
        int j = mid;
        int k = 0;

        while(i < mid && j < e){
            if(array[i] < array[j]){
                mix[k] = array[i];
                i++;
            }else{
                mix[k] = array[j];
                j++;
            }
            k++;
        }

        while(i < mid){
            mix[k] = array[i];
            i++;
            k++;
        }

        while(j < e){
            mix[k] = array[j];
            j++;
            k++;
        }

        for(int l=0; l<mix.length; l++){
            array[s+l] = mix[l];
        }
    }

    public static void main(String[] args) {

        int[] array = {0,1,2,1,2,0,2,0,1};

        mergeSort(array, 0, array.length);

        System.out.println(Arrays.toString(array));

    }

}
