package Interview;

class ThreadEx extends Thread {
    private final String message;

    public ThreadEx(String message) {
        this.message = message;
    }

    @Override
    public void run() {
        for (int i = 0; i < 5; i++) {
            System.out.println(message + " " + i);

            try {
                Thread.sleep(1000);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

public class ConcuurencyUsingThread {
    public static void main(String[] args) {
        ThreadEx thread1 = new ThreadEx("Thread 1:");
        ThreadEx thread2 = new ThreadEx("Thread 2:");

        thread1.start();
        thread2.start();

    }
}
