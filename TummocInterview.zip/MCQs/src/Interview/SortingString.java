package Interview;

import java.util.*;

public class SortingString {

    static void sortOnLength(String input){

        StringBuilder result = new StringBuilder();

        String[] inputArray = input.split("\\s");

        for(int i=0; i< inputArray.length; i++){
            for(int j=1; j< inputArray.length-i; j++){
                if(inputArray[j].length() > inputArray[j-1].length()){
                    String temp = inputArray[j];
                    inputArray[j] = inputArray[j-1];
                    inputArray[j-1] = temp;
                }
            }
        }

        for(String s : inputArray){
            result.append(s + " ");
        }

        System.out.println(result.toString().trim());

    }

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        String input = scan.nextLine();

        sortOnLength(input);

    }

}
