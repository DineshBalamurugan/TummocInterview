package Interview;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class RoutesAndFares {

    public static void main(String[] args) {

        HashMap<String, Integer> routesAndFaresMap = new HashMap<>();

        routesAndFaresMap.put("13", 10);
        routesAndFaresMap.put("13-c", 15);
        routesAndFaresMap.put("342-R", 10);
        routesAndFaresMap.put("146-Q", 10);
        routesAndFaresMap.put("27", 15);
        routesAndFaresMap.put("29-A", 12);
        routesAndFaresMap.put("215-U", 12);
        routesAndFaresMap.put("27-E1", 15);
        routesAndFaresMap.put("13J", 12);
        routesAndFaresMap.put("SBS-D34G", 10);

        HashMap<Integer, List<String>> result = new HashMap<>();

        for(Map.Entry<String, Integer> m : routesAndFaresMap.entrySet()){
            if(!result.containsKey(m.getValue())){
                List<String> tempRoutesList = new LinkedList<>();
                tempRoutesList.add(m.getKey().toString());
                result.put((int)m.getValue(), tempRoutesList);
            }else{
                List<String> existingRoutes = result.get(m.getValue());
                existingRoutes.add(m.getKey().toString());
                result.put((int)m.getValue(), existingRoutes);
            }
        }

        for(Map.Entry<Integer, List<String>> resultMap : result.entrySet()){
            System.out.println(resultMap.getKey() + " " + resultMap.getValue());
        }

    }

}
