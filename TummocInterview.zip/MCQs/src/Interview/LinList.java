package Interview;

public class LinList {

    private Node head;
    private Node tail;

    public void add(int val){
        if(tail == null){
            Node node = new Node(val);
            node.next = head;
            head = node;
            tail = head;
        }else {
            Node node = new Node(val);
            tail.next = node;
            tail = node;
        }
    }

    public void reverseDisplay(){
        reverse(head);
    }

    public void reverse(Node val){
        if(val == null){
            return;
        }
        reverse(val.next);

        System.out.print(val.value + "->>");
    }

    public static void main(String[] args) {

        LinList list = new LinList();

        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);

        list.reverseDisplay();

    }

    private class Node{

        private int value;
        private Node next;

        public Node(int value){
            this.value = value;
        }

        public Node(int value, Node next){
            this.value = value;
            this.next = next;
        }

    }

}
