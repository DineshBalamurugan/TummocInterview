package Interview;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class addDates {

    static void addGivenDays(LocalDate date, int days){

        LocalDate dateAfterAddition = date.plusDays(days);

        System.out.println(dateAfterAddition);

    }

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        int days = scan.nextInt();

        scan.nextLine();

        String date = scan.nextLine();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        LocalDate localDate = LocalDate.parse(date, formatter);

        addGivenDays(localDate, days);

    }

}
